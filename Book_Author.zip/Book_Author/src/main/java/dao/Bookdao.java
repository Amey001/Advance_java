package dao;

import pojos.Book;

public interface Bookdao {
	String registerBook(Book newbook,String email);

}
