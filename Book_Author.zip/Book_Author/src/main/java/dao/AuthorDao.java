package dao;

import pojos.Author;

public interface AuthorDao {
	String registernewAuthor(Author e);

}
